const mongoose = require('mongoose');

const entrySchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  type: { type: String, enum: ['schedule', 'duty', 'homework', 'exam', 'note', 'event'], required: true },
  title: { type: String, required: true, trim: true, maxlength: 160 },
  details: { type: String, default: '', maxlength: 5000 },
  startAt: { type: Date, default: null },
  endAt: { type: Date, default: null },
  completed: { type: Boolean, default: false },
  clientId: { type: String, default: null },
  updatedAt: { type: Date, default: Date.now }
}, { versionKey: false });

entrySchema.index({ userId: 1, updatedAt: 1 });
entrySchema.index({ userId: 1, clientId: 1 }, { unique: true, sparse: true });
module.exports = mongoose.model('Entry', entrySchema);
