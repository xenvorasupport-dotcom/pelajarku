const router = require('express').Router();
const Entry = require('../models/Entry');
const auth = require('../middleware/auth');
router.use(auth);

const allowedTypes = ['schedule', 'duty', 'homework', 'exam', 'note', 'event'];
function cleanPayload(body) {
  const out = {};
  for (const key of ['type', 'title', 'details', 'startAt', 'endAt', 'completed', 'clientId']) {
    if (body[key] !== undefined) out[key] = body[key];
  }
  if (out.type && !allowedTypes.includes(out.type)) throw new Error('Jenis data tidak dikenal.');
  if (out.title !== undefined && (typeof out.title !== 'string' || !out.title.trim() || out.title.length > 160)) throw new Error('Judul wajib diisi (maksimal 160 karakter).');
  if (out.details !== undefined && (typeof out.details !== 'string' || out.details.length > 5000)) throw new Error('Detail maksimal 5000 karakter.');
  if (out.completed !== undefined && typeof out.completed !== 'boolean') throw new Error('completed harus boolean.');
  for (const k of ['startAt', 'endAt']) if (out[k] !== undefined && out[k] !== null && Number.isNaN(Date.parse(out[k]))) throw new Error(`Format ${k} tidak valid.`);
  return out;
}

router.get('/', async (req, res, next) => {
  try {
    const { type, updatedSince } = req.query;
    const filter = { userId: req.userId };
    if (type && allowedTypes.includes(type)) filter.type = type;
    if (updatedSince && !Number.isNaN(Date.parse(updatedSince))) filter.updatedAt = { $gt: new Date(updatedSince) };
    const items = await Entry.find(filter).sort({ updatedAt: 1 }).limit(1000).lean();
    res.json({ items, serverTime: new Date().toISOString() });
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const data = cleanPayload(req.body || {});
    if (!data.type || !data.title) return res.status(400).json({ message: 'type dan title wajib diisi.' });
    const item = await Entry.create({ ...data, userId: req.userId, updatedAt: new Date() });
    res.status(201).json({ item });
  } catch (e) { if (e.code === 11000) return res.status(409).json({ message: 'clientId sudah digunakan.' }); if (e.message && !e.status) return res.status(400).json({ message: e.message }); next(e); }
});

router.patch('/:id', async (req, res, next) => {
  try {
    const data = cleanPayload(req.body || {});
    delete data.clientId;
    const item = await Entry.findOneAndUpdate({ _id: req.params.id, userId: req.userId }, { $set: { ...data, updatedAt: new Date() } }, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: 'Data tidak ditemukan.' });
    res.json({ item });
  } catch (e) { if (e.message && !e.status) return res.status(400).json({ message: e.message }); next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const item = await Entry.findOneAndDelete({ _id: req.params.id, userId: req.userId });
    if (!item) return res.status(404).json({ message: 'Data tidak ditemukan.' });
    res.json({ message: 'Data dihapus.' });
  } catch (e) { next(e); }
});

// Endpoint batch sederhana untuk antrean sinkronisasi dari perangkat.
router.post('/sync', async (req, res, next) => {
  try {
    const changes = Array.isArray(req.body?.changes) ? req.body.changes : null;
    if (!changes || changes.length > 100) return res.status(400).json({ message: 'changes harus berupa array maksimal 100 item.' });
    const results = [];
    for (const raw of changes) {
      try {
        const data = cleanPayload(raw);
        if (!data.type || !data.title || !data.clientId) throw new Error('type, title, dan clientId wajib.');
        const item = await Entry.findOneAndUpdate(
          { userId: req.userId, clientId: data.clientId },
          { $set: { ...data, userId: req.userId, updatedAt: new Date() } },
          { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
        );
        results.push({ clientId: data.clientId, ok: true, item });
      } catch (err) { results.push({ clientId: raw?.clientId || null, ok: false, message: err.message }); }
    }
    res.json({ results, serverTime: new Date().toISOString() });
  } catch (e) { next(e); }
});

module.exports = router;
