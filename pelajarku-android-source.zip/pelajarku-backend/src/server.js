require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const authRoutes = require('./routes/auth');
const entryRoutes = require('./routes/entries');

if (!process.env.MONGODB_URI || !process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('MONGODB_URI dan JWT_SECRET (minimal 32 karakter) wajib diatur.');
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : false }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/api/health', (req, res) => res.json({ ok: true, service: 'PelajarKu API' }));
app.use('/api/auth', authRoutes);
app.use('/api/entries', entryRoutes);
app.use((req, res) => res.status(404).json({ message: 'Endpoint tidak ditemukan.' }));
app.use((err, req, res, next) => {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({ message: 'Data tidak valid.' });
  res.status(500).json({ message: 'Terjadi kesalahan server.' });
});

const port = Number(process.env.PORT || 3000);
mongoose.connect(process.env.MONGODB_URI).then(() => {
  app.listen(port, '127.0.0.1', () => console.log(`PelajarKu API aktif di 127.0.0.1:${port}`));
}).catch(err => { console.error('Gagal terhubung ke MongoDB:', err.message); process.exit(1); });
