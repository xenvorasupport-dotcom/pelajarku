# PelajarKu API — starter backend

Backend awal untuk aplikasi PelajarKu. Ini belum termasuk aplikasi Flutter Android, tampilan UI, notifikasi push, atau sinkronisasi konflik offline tingkat lanjut.

## Fitur saat ini
- Registrasi dan login email/password (password di-hash dengan bcrypt).
- JWT untuk autentikasi.
- Data agenda per pengguna: `schedule`, `duty`, `homework`, `exam`, `note`, `event`.
- CRUD data agenda dan endpoint batch `/api/entries/sync`.
- Helmet, rate limit, validasi dasar, dan pembatasan data berdasarkan user ID.

## Menjalankan untuk uji lokal
Butuh Node.js 20+ dan MongoDB yang sedang berjalan.

```bash
npm install
cp .env.example .env
```

Edit `.env`, isi `MONGODB_URI`, lalu buat `JWT_SECRET` acak minimal 32 karakter. Jalankan:

```bash
npm start
```

Cek `http://127.0.0.1:3000/api/health` dari mesin server.

## Endpoint
- `POST /api/auth/register` — `{ "name": "Nama", "email": "nama@example.com", "password": "minimal8karakter" }`
- `POST /api/auth/login` — `{ "email": "nama@example.com", "password": "minimal8karakter" }`
- `GET /api/entries` — perlu header `Authorization: Bearer TOKEN`
- `POST /api/entries` — buat item agenda
- `PATCH /api/entries/:id` — ubah item
- `DELETE /api/entries/:id` — hapus item
- `POST /api/entries/sync` — `{ "changes": [{ "clientId": "id-unik-dari-perangkat", "type": "homework", "title": "Tugas Matematika" }] }`

## Deploy Ubuntu VPS (ringkasan)
1. Gunakan Ubuntu 24.04 LTS, buat user non-root, dan aktifkan SSH key.
2. Pasang Node.js 20+, MongoDB Community Edition, Nginx, dan PM2.
3. Simpan `.env` di server; jangan masukkan ke Git atau kirim ke chat.
4. Jalankan aplikasi di localhost saja; Nginx menjadi reverse proxy HTTPS ke port 3000.
5. Firewall hanya izinkan SSH dan HTTP/HTTPS. Jangan buka port MongoDB `27017` ke internet.
6. Aktifkan backup MongoDB dan pembaruan keamanan rutin.

Detail langkah instalasi akan disesuaikan setelah diketahui penyedia VPS dan akses yang tersedia.
