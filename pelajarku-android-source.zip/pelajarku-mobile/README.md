# PelajarKu Android (Flutter)

Aplikasi agenda sekolah Android dengan tampilan Flutter, data lokal offline, dan struktur siap dikembangkan untuk sinkronisasi API.

## Isi versi awal
- Dashboard ringkas dan menu cepat
- Jadwal, PR, piket, ujian, kegiatan, catatan
- Tambah dan hapus agenda; tandai PR/piket/ujian selesai
- Data tersimpan lokal di perangkat menggunakan SharedPreferences
- Workflow GitHub Actions untuk membangun APK tanpa komputer lokal

## Build APK dari HP Android
1. Buat akun GitHub dan buat repository baru bernama `pelajarku`.
2. Upload seluruh isi folder proyek ini ke repository (bukan file ZIP-nya saja).
3. Buka tab **Actions**, pilih workflow **Build PelajarKu APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
4. Setelah selesai, buka hasil run dan unduh artifact `pelajarku-release-apk`.
5. Ekstrak artifact ZIP, lalu pasang `app-release.apk` di Android. Izinkan pemasangan dari sumber tersebut jika Android meminta.

## Catatan
Versi ini adalah aplikasi Android Flutter, bukan website. Ini prototipe fungsional lokal; login akun sungguhan, notifikasi terjadwal, sinkronisasi server, dan rilis Play Store belum diaktifkan. Backend Node.js/MongoDB berada di paket `pelajarku-backend` terpisah dan perlu dikonfigurasi/deploy sebelum sinkronisasi online.
