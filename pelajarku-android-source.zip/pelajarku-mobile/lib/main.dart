import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() => runApp(const PelajarKuApp());

const ink = Color(0xFF24324A);
const purple = Color(0xFF7057E8);
const mint = Color(0xFF42C6A5);
const orange = Color(0xFFFFB454);

class PelajarKuApp extends StatelessWidget {
  const PelajarKuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PelajarKu', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      colorScheme: ColorScheme.fromSeed(seedColor: purple), fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF7F8FC), foregroundColor: ink, elevation: 0)),
    home: const HomeShell(),
  );
}

class SchoolEntry {
  SchoolEntry({required this.id, required this.type, required this.title, required this.detail, required this.date, this.done = false});
  final String id, type, title, detail, date;
  bool done;
  Map<String, dynamic> toJson() => {'id':id,'type':type,'title':title,'detail':detail,'date':date,'done':done};
  factory SchoolEntry.fromJson(Map<String, dynamic> j) => SchoolEntry(id:j['id']??const Uuid().v4(), type:j['type']??'Catatan', title:j['title']??'', detail:j['detail']??'', date:j['date']??DateTime.now().toIso8601String(), done:j['done']??false);
}

class HomeShell extends StatefulWidget { const HomeShell({super.key}); @override State<HomeShell> createState()=>_HomeShellState(); }
class _HomeShellState extends State<HomeShell> {
  int tab = 0; bool loading = true;
  List<SchoolEntry> entries = [];
  final pages = const ['Beranda','Jadwal','Tugas','Catatan','Profil'];
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    final p=await SharedPreferences.getInstance(); final raw=p.getString('entries');
    if(raw!=null){try{entries=(jsonDecode(raw) as List).map((e)=>SchoolEntry.fromJson(e)).toList();}catch(_){}}
    if(entries.isEmpty){entries=[
      SchoolEntry(id:'demo1',type:'Jadwal',title:'Matematika',detail:'07.00 – 08.30 • Ruang  X-A',date:DateTime.now().toIso8601String()),
      SchoolEntry(id:'demo2',type:'PR',title:'Latihan Aljabar',detail:'Halaman 24 nomor 1–10',date:DateTime.now().add(const Duration(days:1)).toIso8601String()),
      SchoolEntry(id:'demo3',type:'Piket',title:'Piket kelas',detail:'Kelompok 2 • menyapu dan merapikan kelas',date:DateTime.now().toIso8601String()),
      SchoolEntry(id:'demo4',type:'Ujian',title:'Ulangan IPA',detail:'Bab Sistem Pernapasan',date:DateTime.now().add(const Duration(days:3)).toIso8601String()),
    ]; await _save();}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> _save() async {final p=await SharedPreferences.getInstance(); await p.setString('entries',jsonEncode(entries.map((e)=>e.toJson()).toList()));}
  List<SchoolEntry> get visible => entries.where((e)=> tab==1?e.type=='Jadwal':tab==2?['PR','Ujian','Piket'].contains(e.type):tab==3?e.type=='Catatan':true).toList()..sort((a,b)=>a.date.compareTo(b.date));
  Future<void> _add() async {
    final title=TextEditingController(), detail=TextEditingController(); String type=tab==1?'Jadwal':tab==2?'PR':'Catatan'; DateTime date=DateTime.now();
    await showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:Colors.white,builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>Padding(padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Tambah agenda',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:ink)),const SizedBox(height:16),
      DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'Jenis agenda',border:OutlineInputBorder()),items:['Jadwal','PR','Piket','Ujian','Catatan','Kegiatan'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setSheet(()=>type=v??'Catatan')),
      const SizedBox(height:12),TextField(controller:title,decoration:const InputDecoration(labelText:'Judul',hintText:'Contoh: Tugas Bahasa Indonesia',border:OutlineInputBorder())),const SizedBox(height:12),
      TextField(controller:detail,maxLines:2,decoration:const InputDecoration(labelText:'Keterangan',border:OutlineInputBorder())),const SizedBox(height:12),
      OutlinedButton.icon(onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:date,firstDate:DateTime(2020),lastDate:DateTime(2035));if(d!=null)setSheet(()=>date=d);},icon:const Icon(Icons.calendar_month),label:Text('Tanggal: ${date.day}/${date.month}/${date.year}')),
      const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton(onPressed:(){if(title.text.trim().isEmpty)return;setState(()=>entries.add(SchoolEntry(id:const Uuid().v4(),type:type,title:title.text.trim(),detail:detail.text.trim(),date:date.toIso8601String())));_save();Navigator.pop(ctx);},child:const Text('Simpan agenda')))
    ]))));
  }
  @override Widget build(BuildContext context){
    final Widget body=loading?const Center(child:CircularProgressIndicator()):tab==4?_profile():tab==0?_dashboard():_listPage();
    return Scaffold(body:SafeArea(child:body),floatingActionButton:tab==4?null:FloatingActionButton.extended(onPressed:_add,backgroundColor:purple,foregroundColor:Colors.white,icon:const Icon(Icons.add),label:const Text('Tambah')),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Beranda'),NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'Jadwal'),NavigationDestination(icon:Icon(Icons.assignment_outlined),selectedIcon:Icon(Icons.assignment),label:'Tugas'),NavigationDestination(icon:Icon(Icons.sticky_note_2_outlined),selectedIcon:Icon(Icons.sticky_note_2),label:'Catatan'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profil')]),);
  }
  Widget _dashboard(){final today=DateTime.now();final todayItems=entries.where((e){final d=DateTime.tryParse(e.date)??today;return d.year==today.year&&d.month==today.month&&d.day==today.day;}).toList();final tasks=entries.where((e)=>['PR','Ujian','Piket'].contains(e.type)&&!e.done).length;
    return ListView(padding:const EdgeInsets.fromLTRB(20,12,20,100),children:[
      Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:purple.withOpacity(.12),borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.school_rounded,color:purple,size:28)),const SizedBox(width:12),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('PelajarKu',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:ink)),Text('Teman belajar setiap hari',style:TextStyle(color:Colors.black54))]),const Spacer(),IconButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Notifikasi akan aktif setelah modul pengingat dipasang.'))),icon:const Icon(Icons.notifications_none_rounded))]),
      const SizedBox(height:22),Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF7863EF),Color(0xFF9B83F5)]),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Halo, Pelajar Hebat! 👋',style:TextStyle(color:Colors.white,fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('Yuk, atur kegiatan sekolahmu hari ini.',style:TextStyle(color:Colors.white70)),const SizedBox(height:18),Row(children:[_heroStat('${todayItems.length}','Agenda hari ini'),const SizedBox(width:24),_heroStat('$tasks','Tugas belum selesai')])]),),
      const SizedBox(height:24),_sectionTitle('Menu cepat'),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:4,mainAxisSpacing:12,crossAxisSpacing:8,children:[_quick('Jadwal',Icons.calendar_month, const Color(0xFFEAE6FF),()=>setState(()=>tab=1)),_quick('PR',Icons.menu_book, const Color(0xFFFFEEDB),()=>setState(()=>tab=2)),_quick('Piket',Icons.cleaning_services, const Color(0xFFDDF8F0),()=>setState(()=>tab=2)),_quick('Catatan',Icons.edit_note, const Color(0xFFFFE2E9),()=>setState(()=>tab=3))]),
      const SizedBox(height:22),_sectionTitle('Agenda hari ini'),if(todayItems.isEmpty)_empty('Belum ada agenda hari ini') else ...todayItems.map(_entryCard),
      const SizedBox(height:12),_sectionTitle('Segera datang'),...entries.where((e){final d=DateTime.tryParse(e.date)??today;return d.isAfter(DateTime(today.year,today.month,today.day,23,59));}).take(3).map(_entryCard)
    ]);
  }
  Widget _heroStat(String n,String label)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(n,style:const TextStyle(color:Colors.white,fontSize:27,fontWeight:FontWeight.bold)),Text(label,style:const TextStyle(color:Colors.white70,fontSize:12))]);
  Widget _sectionTitle(String s)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Text(s,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:ink)));
  Widget _quick(String s,IconData i,Color c,VoidCallback onTap)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Column(children:[Container(height:55,width:60,decoration:BoxDecoration(color:c,borderRadius:BorderRadius.circular(17)),child:Icon(i,color:ink)),const SizedBox(height:6),Text(s,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600))]));
  Widget _listPage(){return ListView(padding:const EdgeInsets.fromLTRB(20,18,20,100),children:[Text(pages[tab],style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:ink)),const SizedBox(height:6),Text(tab==1?'Atur mata pelajaran dan jam belajar.':tab==2?'Pantau PR, piket, dan jadwal ujian.':'Simpan ide dan hal pentingmu.',style:const TextStyle(color:Colors.black54)),const SizedBox(height:20),if(visible.isEmpty)_empty('Belum ada data. Tekan tombol Tambah untuk memulai.') else ...visible.map(_entryCard)]);}
  Widget _entryCard(SchoolEntry e){final color=e.type=='PR'?orange:e.type=='Jadwal'?purple:e.type=='Piket'?mint:e.type=='Ujian'?const Color(0xFFFF7D8D):const Color(0xFF69A7E8);final d=DateTime.tryParse(e.date)??DateTime.now();return Card(color:Colors.white,elevation:0,margin:const EdgeInsets.only(bottom:10),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17),side:BorderSide(color:Colors.black.withOpacity(.04))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:15,vertical:6),leading:Container(width:44,height:44,decoration:BoxDecoration(color:color.withOpacity(.15),borderRadius:BorderRadius.circular(13)),child:Icon(_iconFor(e.type),color:color)),title:Text(e.title,style:TextStyle(fontWeight:FontWeight.bold,color:ink,decoration:e.done?TextDecoration.lineThrough:null)),subtitle:Text('${e.type} • ${d.day}/${d.month}/${d.year}\n${e.detail}',maxLines:3,overflow:TextOverflow.ellipsis),isThreeLine:true,trailing:e.type=='PR'||e.type=='Piket'||e.type=='Ujian'?Checkbox(value:e.done,activeColor:mint,onChanged:(v){setState(()=>e.done=v??false);_save();}):PopupMenuButton<String>(onSelected:(v){if(v=='hapus'){setState(()=>entries.removeWhere((x)=>x.id==e.id));_save();}},itemBuilder:(_)=>const [PopupMenuItem(value:'hapus',child:Text('Hapus'))])));}
  IconData _iconFor(String t)=>switch(t){'Jadwal'=>Icons.calendar_month,'PR'=>Icons.menu_book,'Piket'=>Icons.cleaning_services,'Ujian'=>Icons.quiz,'Kegiatan'=>Icons.event,'Catatan'=>Icons.sticky_note_2,_=>Icons.event_note};
  Widget _empty(String s)=>Container(padding:const EdgeInsets.all(25),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Column(children:[const Icon(Icons.inbox_outlined,size:40,color:Colors.black38),const SizedBox(height:8),Text(s,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54))]));
  Widget _profile()=>ListView(padding:const EdgeInsets.all(20),children:[const SizedBox(height:20),const CircleAvatar(radius:42,backgroundColor:Color(0xFFEAE6FF),child:Icon(Icons.person,size:46,color:purple)),const SizedBox(height:12),const Center(child:Text('Profil Pelajar',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:ink))),const Center(child:Text('Akun pribadi PelajarKu',style:TextStyle(color:Colors.black54))),const SizedBox(height:28),_profileTile(Icons.school,'Sekolah','Belum diatur'),_profileTile(Icons.groups,'Kelas','Belum diatur'),_profileTile(Icons.person,'Nama pengguna','Pelajar'),_profileTile(Icons.cloud_sync,'Sinkronisasi','Mode lokal — server belum dihubungkan'),_profileTile(Icons.info_outline,'Tentang aplikasi','PelajarKu versi 1.0.0'),const SizedBox(height:14),const Text('Data agenda saat ini tersimpan di perangkat ini. Hubungkan server untuk sinkronisasi antarperangkat.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54,fontSize:12))]);
  Widget _profileTile(IconData i,String t,String v)=>Card(color:Colors.white,elevation:0,child:ListTile(leading:Icon(i,color:purple),title:Text(t),subtitle:Text(v)));
}
